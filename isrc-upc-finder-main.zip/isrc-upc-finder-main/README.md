# 🎧 ISRC & UPC Finder — Instant Music Metadata Lookup
Search songs or albums by name or URL to quickly access verified music metadata, including **artist, album, label, distributor, ISRC, and UPC codes.**

---

## 🚀 Project Overview  
Welcome to the **ISRC & UPC Finder** project!  
This is a **clean, responsive, and user-friendly tool** designed specifically for **artists, music labels, distributors**, and anyone who needs to retrieve **ISRC (International Standard Recording Code)** and **UPC (Universal Product Code)** for songs and albums.

Built using **HTML, CSS, JavaScript, and Bootstrap**, this tool is lightweight, fast, and works perfectly across all modern devices.

👉 **Live Demo:** [https://isrcupcfinder.ishwarkumar.in/](https://isrcupcfinder.ishwarkumar.in/)

---

## 🔑 Key Features  

### 🔍 ISRC & UPC Search Integration
- Quickly find **ISRC codes** for individual tracks.
- Retrieve **UPC codes** for albums and releases.
- Supports fast lookup for multiple platforms like **Spotify, Apple Music, YouTube Music**, etc.

### 💡 Modern, Responsive UI
- Built with **HTML5, CSS3, Bootstrap 5, and JavaScript**.
- Fully **responsive design** for desktops, tablets, and mobile devices.
- Clean, minimal layout with **Dark/Light Mode toggle**.

### ⚡ Lightweight & Fast
- No heavy frameworks.
- Super-fast loading and easy-to-use interface.

---

## 📂 Technologies Used
- **HTML5**
- **CSS3**
- **Bootstrap 5**
- **JavaScript (Vanilla)**

---

## 🎯 Use Cases
- Independent Artists
- Music Labels
- Distributors
- Digital Marketing Agencies

---

## 📎 License
Released under the **MIT License**.  
Free to use, modify, and distribute.

---

## ✨ Author  
**Ishwar Kumar**  
🌐 [https://ishwarkumar.in/](https://ishwarkumar.in/)
